#include <iostream>
#include <fstream>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <cstring>

#define BUF_SIZE 2000

using namespace std;


int main()
{
	fstream f;

	int emp[100],i;
//	int buf[BUF_SIZE];
	string line,name,desig;
	int n;

	cout<<"Enter the total number of employees:-";
	cin>>n;

	int pid;
	pid = fork();
	if(pid == 0)
	{
		cout<<"Child Starts"<<endl;
		f.open("sample.dat", ios::out);

		if(!f)
		{
			cout<<"\nUnable to open the file"<<endl;
			exit(0);
		}

		f.write(reinterpret_cast<char *>(&emp),sizeof(emp));
		for(i=1;i<=n;i++)
		{
			cout<<"\nName:";
			cin>>name;
			cout<<"\nDesignation:";
			cin>>desig;
		}
		  f.close();
		cout<<"Child terminates"<<endl;

	}
	else
	{
		wait((int *)0);
		cout<<"Parent Starts"<<endl;


		//	cout<<"Sizeof buf : "<<sizeof(buf)<<endl;
	
        //	f.read(reinterpret_cast<char*>(&buf),sizeof(buf));
	
		ofstream fio;
		string line;
		fio.open("sample.dat",ios::out);
		if(!fio)
		{
			cout<<"Unable to open the file"<<endl;
			exit(0);
		}
		cout<<"opened successfully"<<endl;
		getline(cin,line);
		fio<<line<<endl;


		fio.close();
		cout<<"Parent terminates"<<endl;
	}
	return 0;
}

