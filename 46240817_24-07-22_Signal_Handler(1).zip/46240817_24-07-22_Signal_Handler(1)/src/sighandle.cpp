/*#iniclude <iostream>
#include <signal.h>
#include <errno.h>
#include <string>
#include <cstring>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

using namespace std;*/

#include <header.h>

void signal_handler(int signum)
{
//cout<<"Signal handler for signal:"<<signum<<endl;
switch(signum)
{
case SIGSEGV:
cout<<"Signal Number:"<<signum<<endl;
cout<<"Segmentation fault error"<<endl;
exit (EXIT_FAILURE);
break;

case SIGUSR1:
cout<<"Signal Number"<<signum<<endl;
cout<<"Welcome User"<<endl;
exit (EXIT_FAILURE);
break;

default:
cout<<"Signal Number"<<signum<<endl;
cout<<"Unhandled Signal"<<endl;
exit (EXIT_FAILURE);
}
}

void signalhandler()
{
signal(SIGSEGV, signal_handler);
signal(SIGUSR1, signal_handler);
}

void mystrcat()
{
cout<<"Enter two strings:"<<endl;
char str1[20], str2[20];
char* str3 = NULL;
cin>>str1;
cin>>str2;
cout<<"String 1:"<<str1<<endl;
cout<<"String 2:"<<str2<<endl;

str3 = strcat(str1, str2);
cout<<"String:"<<str3;
}

/*int main()
{

mystrcat();

sighandler_t ret = signal(SIGINT, signal_handler);
//signal(SIGSEGV, signal_handler);
signalhandler();

if(ret == SIG_ERR)
{
cout<<"SIGINT set error"<<errno;
return(EXIT_FAILURE);
}



sleep(1);
while(1)
{
cout<<"Signal demo:While loop"<<endl;
}
return 0;

}*/
