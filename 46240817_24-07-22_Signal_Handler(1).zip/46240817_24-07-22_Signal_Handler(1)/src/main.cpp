#include <header.h>

int main()
{

mystrcat();

sighandler_t ret = signal(SIGINT, signal_handler);
signalhandler();

if(ret == SIG_ERR)
{
cout<<"SIGINT set error"<<errno;
return(EXIT_FAILURE);
}

sleep(1);
while(1)
{
cout<<"Signal demo:While loop"<<endl;
}
return 0;

}
