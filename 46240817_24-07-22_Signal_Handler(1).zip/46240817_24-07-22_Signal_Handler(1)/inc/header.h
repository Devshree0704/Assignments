#include <iostream>
#include <signal.h>
#include <errno.h>
#include <string>
#include <cstring>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

using namespace std;

void mystrcat();
void signal_handler(int);
void signalhandler();
