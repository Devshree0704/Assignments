#include <iostream>
#include <string>
#include <cstring>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

using namespace std;

int main(int argc,char* argv[])
{

	int pid,i,N;

	N=stoi(argv[1]);

	pid = fork();
	if(pid == 0)
	{
		//Child Process
		cout<<"Odd Numbers:"<<endl;
			for(i=1;i<=N;i++)
			{
				if(i%2!=0)
					cout<<i<<endl;
			}
	}
	else
	{
		//Parent Process
		sleep(5);
		cout<<"Even Numbers:"<<endl;
			for(i=1;i<=N;i++)
			{
				if(i%2==0)
					cout<<i<<endl;
			}
	}
	return 0;
}
