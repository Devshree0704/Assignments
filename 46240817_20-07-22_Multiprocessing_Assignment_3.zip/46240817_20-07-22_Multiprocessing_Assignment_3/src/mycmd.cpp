#include <header.h>

int main(int argc, char *argv[])
{
	//char *temp[2];
	//temp[0]=argv[1];
	//temp[1]=argv[2];
	cout<<"Exec starts"<<endl;
	execv("/home/linux/day190722/myexecutable",argv);
	cout<<"\nThis will not print"<<endl;
	return 0;

}
