#include<header.h>

using namespace std;

int main(int argc,char* argv[])
{
	Multipro M;
	
	string str,line;
	int pid;
	str=argv[1];
	cout<<str<<endl;

	//	string str,line;
	//	int pid;

	pid =fork();

	if(pid==0)
	{
		cout<<"Child Process"<<endl;
		cout<<"PID:"<<getpid()<<endl;
		cout<<"PPID:"<<getppid()<<endl;

		fstream file;
		file.open(argv[1],ios::out|ios::trunc);
		if(!file)
		{
			cout<<"Unable to open file"<<endl;
		}
		else
		{
			cout<<"Successfully opened file"<<endl;
			cout<<"Enter contents into file"<<endl;
		}
		//while(file.good())
		//{
		getline(cin,line);
		file<<line<<endl;
		//	file<<line<<endl;
		//}
		file.close();
	}


	else
	{
		//int stat;

		wait(0);
		cout<<"Parent Process"<<endl;
		cout<<"PID:"<<getpid()<<endl;

		fstream file;
		file.open(argv[1],ios::in|ios::out);
		if(!file)
		{
			cout<<"Unable to open file"<<endl;
		}
		else
		{
			cout<<"Successfully opened the file"<<endl;
		}
		//while(file.good())
		//{
		//file>>line;
		getline(file,line);
		cout<<line<<endl; 
		//}
		file.close();
		/*if(WIFEXITED(stat))
		{
			cout<<"Child terminated with status:"<<WEXITSTATUS(stat);
		}*/
		M.process_display_exit_code();

	}
	return 0;
}
