#include <header.h>

using namespace std;

void Multipro ::process_display_exit_code()
{
	int stat;
	if(WIFEXITED(stat))
	{
		cout<<"Child terminated with status:"<<WEXITSTATUS(stat);

	}
	return 0;
}


