#pragma once

#include <iostream>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fstream>
#include <stdlib.h>
#include <string>
#include <cstring>

class Multipro
{
	private:
		int stat;
	public:
		void process_display_exit_code();
};

