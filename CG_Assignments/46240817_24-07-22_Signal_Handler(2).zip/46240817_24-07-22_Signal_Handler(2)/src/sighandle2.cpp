/*#include <iostream>
#include <csignal>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

using namespace std;*/

#include <header.h>

void signalhandle(int ID)
{
cout<<"ID:"<<ID<<endl;
exit (EXIT_FAILURE);
}

void RegisterSignal()
{
signal(SIGCHLD, signalhandle);
}

void parentchild()
{
pid_t pid;
pid = fork();
int status;
if(pid == 0)
{
cout<<"Child Process"<<endl;
cout<<"PID:"<<getpid()<<endl;
cout<<"PPID:"<<getppid()<<endl;
for(;;);
}
else
{
waitpid(pid, &status, 0);

cout<<"Parent process"<<endl;
cout<<"PID:"<<getpid()<<endl;
cout<<"PPID:"<<getppid()<<endl;

RegisterSignal();
}
}

/*int main()
{
parentchild();
for(;;);
return (EXIT_SUCCESS);
}*/
