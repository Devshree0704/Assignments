#include <header.h>

int main()
{
parentchild();
for(;;);

return (EXIT_SUCCESS);
}
